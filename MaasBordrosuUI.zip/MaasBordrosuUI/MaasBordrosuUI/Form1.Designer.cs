﻿namespace MaasBordrosuUI
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            pnlSideBar = new Panel();
            panel5 = new Panel();
            btnRaporlar = new Button();
            lblTimer = new Label();
            panel3 = new Panel();
            btnPersonelYonetimi = new Button();
            panel4 = new Panel();
            btnDokumantasyon = new Button();
            panel2 = new Panel();
            btnAnaSayfa = new Button();
            panel1 = new Panel();
            lblLogo = new Label();
            pictureBox1 = new PictureBox();
            panel6 = new Panel();
            lblSayfaBilgisi = new Label();
            panel8 = new Panel();
            btnCikisYap = new Button();
            panel7 = new Panel();
            btnSayfayiAsagiAl = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            panelGiris = new Panel();
            lblAnasayfa4 = new Label();
            lblCizgi = new Label();
            lblAnasayfa3 = new Label();
            lblAnasayfa2 = new Label();
            lblAnasayfa1 = new Label();
            lblAnasayfa = new Label();
            panelPersonelYonetimi = new Panel();
            txtYoneticiBonusu = new TextBox();
            label9 = new Label();
            txtYoneticiSaatlikUcret = new TextBox();
            label8 = new Label();
            txtCalismaSaati = new TextBox();
            label7 = new Label();
            mtbTelNo = new MaskedTextBox();
            btnSil = new Button();
            btnGuncelle = new Button();
            btnEkle = new Button();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            dtpDogumTarihi = new DateTimePicker();
            txtSoyad = new TextBox();
            txtAd = new TextBox();
            cmbMemurDerecesi = new ComboBox();
            cmbStatu = new ComboBox();
            lstvBilgiCRUD = new ListView();
            panelDokumantasyon = new Panel();
            label11 = new Label();
            label10 = new Label();
            lstvMemurlar = new ListView();
            lstvYoneticiler = new ListView();
            panelRaporlar = new Panel();
            btnAzCalisan = new Button();
            btnJsonOku = new Button();
            label14 = new Label();
            label16 = new Label();
            label13 = new Label();
            label15 = new Label();
            label12 = new Label();
            btnPDF = new Button();
            btnJSON = new Button();
            pnlSideBar.SuspendLayout();
            panel5.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel6.SuspendLayout();
            panel8.SuspendLayout();
            panel7.SuspendLayout();
            panelGiris.SuspendLayout();
            panelPersonelYonetimi.SuspendLayout();
            panelDokumantasyon.SuspendLayout();
            panelRaporlar.SuspendLayout();
            SuspendLayout();
            // 
            // pnlSideBar
            // 
            pnlSideBar.BackColor = Color.FromArgb(31, 30, 68);
            pnlSideBar.Controls.Add(panel5);
            pnlSideBar.Controls.Add(lblTimer);
            pnlSideBar.Controls.Add(panel3);
            pnlSideBar.Controls.Add(panel4);
            pnlSideBar.Controls.Add(panel2);
            pnlSideBar.Controls.Add(panel1);
            pnlSideBar.Dock = DockStyle.Left;
            pnlSideBar.Location = new Point(0, 0);
            pnlSideBar.Name = "pnlSideBar";
            pnlSideBar.Size = new Size(251, 725);
            pnlSideBar.TabIndex = 0;
            // 
            // panel5
            // 
            panel5.Controls.Add(btnRaporlar);
            panel5.Location = new Point(3, 560);
            panel5.Name = "panel5";
            panel5.Size = new Size(245, 102);
            panel5.TabIndex = 2;
            // 
            // btnRaporlar
            // 
            btnRaporlar.BackColor = Color.Transparent;
            btnRaporlar.FlatStyle = FlatStyle.Flat;
            btnRaporlar.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            btnRaporlar.ForeColor = SystemColors.ButtonHighlight;
            btnRaporlar.Image = (Image)resources.GetObject("btnRaporlar.Image");
            btnRaporlar.ImageAlign = ContentAlignment.MiddleLeft;
            btnRaporlar.Location = new Point(-23, -3);
            btnRaporlar.Margin = new Padding(0);
            btnRaporlar.Name = "btnRaporlar";
            btnRaporlar.Padding = new Padding(30, 0, 0, 0);
            btnRaporlar.Size = new Size(285, 108);
            btnRaporlar.TabIndex = 3;
            btnRaporlar.Text = "Raporlar";
            btnRaporlar.UseVisualStyleBackColor = false;
            btnRaporlar.Click += btnRaporlar_Click;
            btnRaporlar.MouseEnter += btnRaporlar_MouseEnter;
            btnRaporlar.MouseLeave += btnRaporlar_MouseLeave;
            // 
            // lblTimer
            // 
            lblTimer.AutoSize = true;
            lblTimer.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblTimer.ForeColor = SystemColors.ButtonHighlight;
            lblTimer.Location = new Point(73, 681);
            lblTimer.Name = "lblTimer";
            lblTimer.Size = new Size(54, 21);
            lblTimer.TabIndex = 2;
            lblTimer.Text = "label1";
            // 
            // panel3
            // 
            panel3.Controls.Add(btnPersonelYonetimi);
            panel3.Location = new Point(3, 344);
            panel3.Name = "panel3";
            panel3.Size = new Size(245, 102);
            panel3.TabIndex = 2;
            // 
            // btnPersonelYonetimi
            // 
            btnPersonelYonetimi.BackColor = Color.Transparent;
            btnPersonelYonetimi.FlatStyle = FlatStyle.Flat;
            btnPersonelYonetimi.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            btnPersonelYonetimi.ForeColor = SystemColors.ButtonHighlight;
            btnPersonelYonetimi.Image = (Image)resources.GetObject("btnPersonelYonetimi.Image");
            btnPersonelYonetimi.ImageAlign = ContentAlignment.MiddleLeft;
            btnPersonelYonetimi.Location = new Point(-23, -6);
            btnPersonelYonetimi.Margin = new Padding(0);
            btnPersonelYonetimi.Name = "btnPersonelYonetimi";
            btnPersonelYonetimi.Padding = new Padding(30, 0, 0, 0);
            btnPersonelYonetimi.Size = new Size(285, 118);
            btnPersonelYonetimi.TabIndex = 3;
            btnPersonelYonetimi.Text = "            Personel Yönetimi";
            btnPersonelYonetimi.UseVisualStyleBackColor = false;
            btnPersonelYonetimi.Click += btnPersonelYonetimi_Click;
            btnPersonelYonetimi.MouseEnter += btnPersonelYonetimi_MouseEnter;
            btnPersonelYonetimi.MouseLeave += btnPersonelYonetimi_MouseLeave;
            // 
            // panel4
            // 
            panel4.Controls.Add(btnDokumantasyon);
            panel4.Location = new Point(3, 452);
            panel4.Name = "panel4";
            panel4.Size = new Size(245, 102);
            panel4.TabIndex = 2;
            // 
            // btnDokumantasyon
            // 
            btnDokumantasyon.BackColor = Color.Transparent;
            btnDokumantasyon.FlatStyle = FlatStyle.Flat;
            btnDokumantasyon.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            btnDokumantasyon.ForeColor = SystemColors.ButtonHighlight;
            btnDokumantasyon.Image = (Image)resources.GetObject("btnDokumantasyon.Image");
            btnDokumantasyon.ImageAlign = ContentAlignment.MiddleLeft;
            btnDokumantasyon.Location = new Point(-23, -6);
            btnDokumantasyon.Margin = new Padding(0);
            btnDokumantasyon.Name = "btnDokumantasyon";
            btnDokumantasyon.Padding = new Padding(30, 0, 0, 0);
            btnDokumantasyon.Size = new Size(285, 111);
            btnDokumantasyon.TabIndex = 3;
            btnDokumantasyon.Text = "          Dokümantasyon";
            btnDokumantasyon.UseVisualStyleBackColor = false;
            btnDokumantasyon.Click += btnDokumantasyon_Click;
            btnDokumantasyon.MouseEnter += btnDokumantasyon_MouseEnter;
            btnDokumantasyon.MouseLeave += btnDokumantasyon_MouseLeave;
            // 
            // panel2
            // 
            panel2.Controls.Add(btnAnaSayfa);
            panel2.Location = new Point(3, 236);
            panel2.Name = "panel2";
            panel2.Size = new Size(245, 102);
            panel2.TabIndex = 2;
            // 
            // btnAnaSayfa
            // 
            btnAnaSayfa.BackColor = Color.Transparent;
            btnAnaSayfa.FlatStyle = FlatStyle.Flat;
            btnAnaSayfa.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            btnAnaSayfa.ForeColor = SystemColors.ButtonHighlight;
            btnAnaSayfa.Image = (Image)resources.GetObject("btnAnaSayfa.Image");
            btnAnaSayfa.ImageAlign = ContentAlignment.MiddleLeft;
            btnAnaSayfa.Location = new Point(-23, -3);
            btnAnaSayfa.Margin = new Padding(0);
            btnAnaSayfa.Name = "btnAnaSayfa";
            btnAnaSayfa.Padding = new Padding(30, 0, 0, 0);
            btnAnaSayfa.Size = new Size(285, 108);
            btnAnaSayfa.TabIndex = 3;
            btnAnaSayfa.Text = "Anasayfa";
            btnAnaSayfa.UseVisualStyleBackColor = false;
            btnAnaSayfa.Click += btnAnaSayfa_Click;
            btnAnaSayfa.MouseEnter += btnAnaSayfa_MouseEnter;
            btnAnaSayfa.MouseLeave += btnAnaSayfa_MouseLeave;
            // 
            // panel1
            // 
            panel1.Controls.Add(lblLogo);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(26, 13);
            panel1.Name = "panel1";
            panel1.Size = new Size(206, 191);
            panel1.TabIndex = 1;
            // 
            // lblLogo
            // 
            lblLogo.AutoSize = true;
            lblLogo.BackColor = Color.Transparent;
            lblLogo.FlatStyle = FlatStyle.Flat;
            lblLogo.Font = new Font("Yu Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblLogo.ForeColor = SystemColors.ButtonHighlight;
            lblLogo.Location = new Point(13, 153);
            lblLogo.Name = "lblLogo";
            lblLogo.Size = new Size(173, 20);
            lblLogo.TabIndex = 1;
            lblLogo.Text = "Maaş Bordrosu Hesapla";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = null;
            pictureBox1.Location = new Point(47, 30);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(116, 109);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(31, 30, 68);
            panel6.Controls.Add(lblSayfaBilgisi);
            panel6.Controls.Add(panel8);
            panel6.Controls.Add(panel7);
            panel6.Dock = DockStyle.Top;
            panel6.Location = new Point(251, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(917, 59);
            panel6.TabIndex = 1;
            // 
            // lblSayfaBilgisi
            // 
            lblSayfaBilgisi.AutoSize = true;
            lblSayfaBilgisi.Font = new Font("Yu Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblSayfaBilgisi.ForeColor = SystemColors.ButtonHighlight;
            lblSayfaBilgisi.Location = new Point(25, 13);
            lblSayfaBilgisi.Name = "lblSayfaBilgisi";
            lblSayfaBilgisi.Size = new Size(79, 31);
            lblSayfaBilgisi.TabIndex = 5;
            lblSayfaBilgisi.Text = "label2";
            // 
            // panel8
            // 
            panel8.Controls.Add(btnCikisYap);
            panel8.Location = new Point(861, 0);
            panel8.Name = "panel8";
            panel8.Size = new Size(56, 59);
            panel8.TabIndex = 6;
            // 
            // btnCikisYap
            // 
            btnCikisYap.BackColor = Color.Transparent;
            btnCikisYap.FlatStyle = FlatStyle.Popup;
            btnCikisYap.Image = (Image)resources.GetObject("btnCikisYap.Image");
            btnCikisYap.Location = new Point(-8, -4);
            btnCikisYap.Name = "btnCikisYap";
            btnCikisYap.Size = new Size(71, 72);
            btnCikisYap.TabIndex = 5;
            btnCikisYap.UseVisualStyleBackColor = false;
            btnCikisYap.Click += btnCikisYap_Click;
            btnCikisYap.MouseEnter += btnCikisYap_MouseEnter;
            btnCikisYap.MouseLeave += btnCikisYap_MouseLeave;
            // 
            // panel7
            // 
            panel7.Controls.Add(btnSayfayiAsagiAl);
            panel7.Location = new Point(799, 0);
            panel7.Name = "panel7";
            panel7.Size = new Size(56, 59);
            panel7.TabIndex = 6;
            // 
            // btnSayfayiAsagiAl
            // 
            btnSayfayiAsagiAl.BackColor = Color.Transparent;
            btnSayfayiAsagiAl.FlatStyle = FlatStyle.Popup;
            btnSayfayiAsagiAl.Image = (Image)resources.GetObject("btnSayfayiAsagiAl.Image");
            btnSayfayiAsagiAl.Location = new Point(-10, -4);
            btnSayfayiAsagiAl.Name = "btnSayfayiAsagiAl";
            btnSayfayiAsagiAl.Size = new Size(78, 72);
            btnSayfayiAsagiAl.TabIndex = 5;
            btnSayfayiAsagiAl.UseVisualStyleBackColor = false;
            btnSayfayiAsagiAl.Click += btnSayfayiAsagiAl_Click;
            btnSayfayiAsagiAl.MouseEnter += btnSayfayiAsagiAl_MouseEnter;
            btnSayfayiAsagiAl.MouseLeave += btnSayfayiAsagiAl_MouseLeave;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // panelGiris
            // 
            panelGiris.Controls.Add(lblAnasayfa4);
            panelGiris.Controls.Add(lblCizgi);
            panelGiris.Controls.Add(lblAnasayfa3);
            panelGiris.Controls.Add(lblAnasayfa2);
            panelGiris.Controls.Add(lblAnasayfa1);
            panelGiris.Controls.Add(lblAnasayfa);
            panelGiris.Location = new Point(254, 65);
            panelGiris.Name = "panelGiris";
            panelGiris.Size = new Size(905, 669);
            panelGiris.TabIndex = 2;
            panelGiris.Visible = false;
            // 
            // lblAnasayfa4
            // 
            lblAnasayfa4.AutoSize = true;
            lblAnasayfa4.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblAnasayfa4.ForeColor = SystemColors.ButtonHighlight;
            lblAnasayfa4.Location = new Point(17, 322);
            lblAnasayfa4.Name = "lblAnasayfa4";
            lblAnasayfa4.Size = new Size(649, 21);
            lblAnasayfa4.TabIndex = 5;
            lblAnasayfa4.Text = "Raporlama sekmesinden ise 150 saaten az çalışan çalışanların raposuna ulaşabilirsiniz.";
            // 
            // lblCizgi
            // 
            lblCizgi.BackColor = SystemColors.ButtonHighlight;
            lblCizgi.Location = new Point(6, 149);
            lblCizgi.Name = "lblCizgi";
            lblCizgi.Size = new Size(884, 1);
            lblCizgi.TabIndex = 4;
            // 
            // lblAnasayfa3
            // 
            lblAnasayfa3.AutoSize = true;
            lblAnasayfa3.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblAnasayfa3.ForeColor = SystemColors.ButtonHighlight;
            lblAnasayfa3.Location = new Point(17, 291);
            lblAnasayfa3.Name = "lblAnasayfa3";
            lblAnasayfa3.Size = new Size(838, 21);
            lblAnasayfa3.TabIndex = 3;
            lblAnasayfa3.Text = "Dokümantasyon sekmesinde çalışanlarınızın listesini görüntüleyebilir, verileri PDF, .JSON olarak kaydedebilirsiniz.";
            // 
            // lblAnasayfa2
            // 
            lblAnasayfa2.AutoSize = true;
            lblAnasayfa2.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblAnasayfa2.ForeColor = SystemColors.ButtonHighlight;
            lblAnasayfa2.Location = new Point(17, 261);
            lblAnasayfa2.Name = "lblAnasayfa2";
            lblAnasayfa2.Size = new Size(653, 21);
            lblAnasayfa2.TabIndex = 2;
            lblAnasayfa2.Text = "Personel yönetimi sekmesinden yeni personel ekleyebilir, mevcut personeli silebilirsiniz.";
            // 
            // lblAnasayfa1
            // 
            lblAnasayfa1.AutoSize = true;
            lblAnasayfa1.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblAnasayfa1.ForeColor = SystemColors.ButtonHighlight;
            lblAnasayfa1.Location = new Point(17, 233);
            lblAnasayfa1.Name = "lblAnasayfa1";
            lblAnasayfa1.Size = new Size(583, 21);
            lblAnasayfa1.TabIndex = 1;
            lblAnasayfa1.Text = "Bu uygulama, çalışanlarınızın maaş bordrolarını kolayca hesaplamanızı sağlar. ";
            // 
            // lblAnasayfa
            // 
            lblAnasayfa.AutoSize = true;
            lblAnasayfa.Font = new Font("Yu Gothic", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblAnasayfa.ForeColor = SystemColors.ButtonHighlight;
            lblAnasayfa.Location = new Point(17, 112);
            lblAnasayfa.Name = "lblAnasayfa";
            lblAnasayfa.Size = new Size(409, 27);
            lblAnasayfa.TabIndex = 0;
            lblAnasayfa.Text = "Maaş Bordro Uygulamasına Hoşgeldiniz.";
            // 
            // panelPersonelYonetimi
            // 
            panelPersonelYonetimi.Controls.Add(txtYoneticiBonusu);
            panelPersonelYonetimi.Controls.Add(label9);
            panelPersonelYonetimi.Controls.Add(txtYoneticiSaatlikUcret);
            panelPersonelYonetimi.Controls.Add(label8);
            panelPersonelYonetimi.Controls.Add(txtCalismaSaati);
            panelPersonelYonetimi.Controls.Add(label7);
            panelPersonelYonetimi.Controls.Add(mtbTelNo);
            panelPersonelYonetimi.Controls.Add(btnSil);
            panelPersonelYonetimi.Controls.Add(btnGuncelle);
            panelPersonelYonetimi.Controls.Add(btnEkle);
            panelPersonelYonetimi.Controls.Add(label6);
            panelPersonelYonetimi.Controls.Add(label5);
            panelPersonelYonetimi.Controls.Add(label4);
            panelPersonelYonetimi.Controls.Add(label3);
            panelPersonelYonetimi.Controls.Add(label2);
            panelPersonelYonetimi.Controls.Add(label1);
            panelPersonelYonetimi.Controls.Add(dtpDogumTarihi);
            panelPersonelYonetimi.Controls.Add(txtSoyad);
            panelPersonelYonetimi.Controls.Add(txtAd);
            panelPersonelYonetimi.Controls.Add(cmbMemurDerecesi);
            panelPersonelYonetimi.Controls.Add(cmbStatu);
            panelPersonelYonetimi.Controls.Add(lstvBilgiCRUD);
            panelPersonelYonetimi.Location = new Point(254, 65);
            panelPersonelYonetimi.Name = "panelPersonelYonetimi";
            panelPersonelYonetimi.Size = new Size(873, 666);
            panelPersonelYonetimi.TabIndex = 3;
            // 
            // txtYoneticiBonusu
            // 
            txtYoneticiBonusu.Location = new Point(605, 538);
            txtYoneticiBonusu.Name = "txtYoneticiBonusu";
            txtYoneticiBonusu.Size = new Size(193, 23);
            txtYoneticiBonusu.TabIndex = 22;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label9.ForeColor = SystemColors.ButtonHighlight;
            label9.Location = new Point(638, 514);
            label9.Name = "label9";
            label9.Size = new Size(128, 21);
            label9.TabIndex = 21;
            label9.Text = "Yönetici Bonusu";
            // 
            // txtYoneticiSaatlikUcret
            // 
            txtYoneticiSaatlikUcret.Location = new Point(328, 538);
            txtYoneticiSaatlikUcret.Name = "txtYoneticiSaatlikUcret";
            txtYoneticiSaatlikUcret.Size = new Size(224, 23);
            txtYoneticiSaatlikUcret.TabIndex = 20;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label8.ForeColor = SystemColors.ButtonHighlight;
            label8.Location = new Point(342, 513);
            label8.Name = "label8";
            label8.Size = new Size(173, 21);
            label8.TabIndex = 19;
            label8.Text = "Yönetici Saatlik Ücreti";
            // 
            // txtCalismaSaati
            // 
            txtCalismaSaati.Location = new Point(592, 444);
            txtCalismaSaati.Name = "txtCalismaSaati";
            txtCalismaSaati.Size = new Size(206, 23);
            txtCalismaSaati.TabIndex = 18;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label7.ForeColor = SystemColors.ButtonHighlight;
            label7.Location = new Point(437, 444);
            label7.Name = "label7";
            label7.Size = new Size(146, 21);
            label7.TabIndex = 17;
            label7.Text = "Aylık çalışma saati";
            // 
            // mtbTelNo
            // 
            mtbTelNo.Location = new Point(592, 356);
            mtbTelNo.Mask = "(999) 000-0000";
            mtbTelNo.Name = "mtbTelNo";
            mtbTelNo.Size = new Size(206, 23);
            mtbTelNo.TabIndex = 16;
            // 
            // btnSil
            // 
            btnSil.FlatStyle = FlatStyle.Flat;
            btnSil.Font = new Font("Segoe UI", 12F);
            btnSil.ForeColor = SystemColors.ButtonHighlight;
            btnSil.Image = Properties.Resources.remove_8573396;
            btnSil.ImageAlign = ContentAlignment.MiddleLeft;
            btnSil.Location = new Point(552, 616);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(224, 39);
            btnSil.TabIndex = 15;
            btnSil.Text = "Personel Sil";
            btnSil.UseVisualStyleBackColor = true;
            btnSil.Click += btnSil_Click;
            // 
            // btnGuncelle
            // 
            btnGuncelle.FlatStyle = FlatStyle.Flat;
            btnGuncelle.Font = new Font("Segoe UI", 12F);
            btnGuncelle.ForeColor = SystemColors.ButtonHighlight;
            btnGuncelle.Image = Properties.Resources.refresh;
            btnGuncelle.ImageAlign = ContentAlignment.MiddleLeft;
            btnGuncelle.Location = new Point(291, 616);
            btnGuncelle.Name = "btnGuncelle";
            btnGuncelle.Size = new Size(224, 39);
            btnGuncelle.TabIndex = 14;
            btnGuncelle.Text = "Personel Bilgisi Güncelle";
            btnGuncelle.TextAlign = ContentAlignment.MiddleRight;
            btnGuncelle.UseVisualStyleBackColor = true;
            btnGuncelle.Click += btnGuncelle_Click;
            // 
            // btnEkle
            // 
            btnEkle.BackColor = Color.Transparent;
            btnEkle.FlatStyle = FlatStyle.Flat;
            btnEkle.Font = new Font("Segoe UI", 12F);
            btnEkle.ForeColor = SystemColors.ButtonHighlight;
            btnEkle.Image = Properties.Resources.image_gallery;
            btnEkle.ImageAlign = ContentAlignment.MiddleLeft;
            btnEkle.Location = new Point(25, 616);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(224, 39);
            btnEkle.TabIndex = 13;
            btnEkle.Text = "Personel Ekle";
            btnEkle.UseVisualStyleBackColor = false;
            btnEkle.Click += btnEkle_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(63, 513);
            label6.Name = "label6";
            label6.Size = new Size(198, 21);
            label6.TabIndex = 12;
            label6.Text = "Memur ise derece seçiniz";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label5.ForeColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(478, 399);
            label5.Name = "label5";
            label5.Size = new Size(108, 21);
            label5.TabIndex = 11;
            label5.Text = "Doğum Tarihi";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Yu Gothic", 12F);
            label4.ForeColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(496, 356);
            label4.Name = "label4";
            label4.Size = new Size(90, 21);
            label4.TabIndex = 10;
            label4.Text = "Telefon No";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Yu Gothic", 12F);
            label3.ForeColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(102, 398);
            label3.Name = "label3";
            label3.Size = new Size(55, 21);
            label3.TabIndex = 9;
            label3.Text = "Soyad";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Yu Gothic", 12F);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(115, 356);
            label2.Name = "label2";
            label2.Size = new Size(29, 21);
            label2.TabIndex = 8;
            label2.Text = "Ad";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Yu Gothic", 12F);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(51, 443);
            label1.Name = "label1";
            label1.Size = new Size(106, 21);
            label1.TabIndex = 7;
            label1.Text = "Statü Seçiniz";
            // 
            // dtpDogumTarihi
            // 
            dtpDogumTarihi.Location = new Point(592, 399);
            dtpDogumTarihi.Name = "dtpDogumTarihi";
            dtpDogumTarihi.Size = new Size(206, 23);
            dtpDogumTarihi.TabIndex = 6;
            // 
            // txtSoyad
            // 
            txtSoyad.Location = new Point(166, 396);
            txtSoyad.Name = "txtSoyad";
            txtSoyad.Size = new Size(206, 23);
            txtSoyad.TabIndex = 4;
            // 
            // txtAd
            // 
            txtAd.Location = new Point(166, 354);
            txtAd.Name = "txtAd";
            txtAd.Size = new Size(206, 23);
            txtAd.TabIndex = 3;
            // 
            // cmbMemurDerecesi
            // 
            cmbMemurDerecesi.FormattingEnabled = true;
            cmbMemurDerecesi.Items.AddRange(new object[] { "1", "2", "3" });
            cmbMemurDerecesi.Location = new Point(63, 538);
            cmbMemurDerecesi.Name = "cmbMemurDerecesi";
            cmbMemurDerecesi.Size = new Size(206, 23);
            cmbMemurDerecesi.TabIndex = 2;
            // 
            // cmbStatu
            // 
            cmbStatu.FormattingEnabled = true;
            cmbStatu.Items.AddRange(new object[] { "Memur", "Yönetici" });
            cmbStatu.Location = new Point(166, 441);
            cmbStatu.Name = "cmbStatu";
            cmbStatu.Size = new Size(206, 23);
            cmbStatu.TabIndex = 1;
            cmbStatu.SelectedIndexChanged += cmbStatu_SelectedIndexChanged;
            // 
            // lstvBilgiCRUD
            // 
            lstvBilgiCRUD.BackColor = Color.FromArgb(31, 30, 68);
            lstvBilgiCRUD.Font = new Font("Yu Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lstvBilgiCRUD.ForeColor = SystemColors.ButtonHighlight;
            lstvBilgiCRUD.Location = new Point(25, 3);
            lstvBilgiCRUD.Name = "lstvBilgiCRUD";
            lstvBilgiCRUD.Size = new Size(830, 328);
            lstvBilgiCRUD.TabIndex = 0;
            lstvBilgiCRUD.UseCompatibleStateImageBehavior = false;
            lstvBilgiCRUD.View = View.Details;
            // 
            // panelDokumantasyon
            // 
            panelDokumantasyon.Controls.Add(label11);
            panelDokumantasyon.Controls.Add(label10);
            panelDokumantasyon.Controls.Add(lstvMemurlar);
            panelDokumantasyon.Controls.Add(lstvYoneticiler);
            panelDokumantasyon.Location = new Point(257, 60);
            panelDokumantasyon.Name = "panelDokumantasyon";
            panelDokumantasyon.Size = new Size(873, 660);
            panelDokumantasyon.TabIndex = 4;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label11.ForeColor = SystemColors.ButtonHighlight;
            label11.Location = new Point(53, 351);
            label11.Name = "label11";
            label11.Size = new Size(218, 21);
            label11.TabIndex = 1;
            label11.Text = "Yönetici Personellerin listesi";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Yu Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label10.ForeColor = SystemColors.ButtonHighlight;
            label10.Location = new Point(53, 24);
            label10.Name = "label10";
            label10.Size = new Size(213, 21);
            label10.TabIndex = 1;
            label10.Text = "Memur Personellerin listesi";
            // 
            // lstvMemurlar
            // 
            lstvMemurlar.BackColor = Color.FromArgb(31, 30, 68);
            lstvMemurlar.Font = new Font("Yu Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lstvMemurlar.ForeColor = SystemColors.ButtonHighlight;
            lstvMemurlar.Location = new Point(31, 65);
            lstvMemurlar.Name = "lstvMemurlar";
            lstvMemurlar.Size = new Size(808, 257);
            lstvMemurlar.TabIndex = 0;
            lstvMemurlar.UseCompatibleStateImageBehavior = false;
            lstvMemurlar.View = View.Details;
            // 
            // lstvYoneticiler
            // 
            lstvYoneticiler.BackColor = Color.FromArgb(31, 30, 68);
            lstvYoneticiler.Font = new Font("Yu Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lstvYoneticiler.ForeColor = SystemColors.ButtonHighlight;
            lstvYoneticiler.Location = new Point(31, 389);
            lstvYoneticiler.Name = "lstvYoneticiler";
            lstvYoneticiler.Size = new Size(808, 257);
            lstvYoneticiler.TabIndex = 0;
            lstvYoneticiler.UseCompatibleStateImageBehavior = false;
            lstvYoneticiler.View = View.Details;
            // 
            // panelRaporlar
            // 
            panelRaporlar.Controls.Add(btnAzCalisan);
            panelRaporlar.Controls.Add(btnJsonOku);
            panelRaporlar.Controls.Add(label14);
            panelRaporlar.Controls.Add(label16);
            panelRaporlar.Controls.Add(label13);
            panelRaporlar.Controls.Add(label15);
            panelRaporlar.Controls.Add(label12);
            panelRaporlar.Controls.Add(btnPDF);
            panelRaporlar.Controls.Add(btnJSON);
            panelRaporlar.Location = new Point(254, 60);
            panelRaporlar.Name = "panelRaporlar";
            panelRaporlar.Size = new Size(887, 646);
            panelRaporlar.TabIndex = 5;
            // 
            // btnAzCalisan
            // 
            btnAzCalisan.BackColor = Color.Transparent;
            btnAzCalisan.FlatStyle = FlatStyle.Flat;
            btnAzCalisan.Font = new Font("Yu Gothic", 12F);
            btnAzCalisan.ForeColor = SystemColors.ButtonHighlight;
            btnAzCalisan.Image = Properties.Resources.refresh;
            btnAzCalisan.ImageAlign = ContentAlignment.MiddleLeft;
            btnAzCalisan.Location = new Point(502, 469);
            btnAzCalisan.Name = "btnAzCalisan";
            btnAzCalisan.Size = new Size(285, 51);
            btnAzCalisan.TabIndex = 6;
            btnAzCalisan.Text = "Az çalışan personellerin listesi";
            btnAzCalisan.TextAlign = ContentAlignment.MiddleRight;
            btnAzCalisan.UseVisualStyleBackColor = false;
            btnAzCalisan.Click += btnAzCalisan_Click;
            // 
            // btnJsonOku
            // 
            btnJsonOku.BackColor = Color.Transparent;
            btnJsonOku.FlatStyle = FlatStyle.Flat;
            btnJsonOku.Font = new Font("Yu Gothic", 12F);
            btnJsonOku.ForeColor = SystemColors.ButtonHighlight;
            btnJsonOku.Image = Properties.Resources.refresh;
            btnJsonOku.ImageAlign = ContentAlignment.MiddleLeft;
            btnJsonOku.Location = new Point(137, 469);
            btnJsonOku.Name = "btnJsonOku";
            btnJsonOku.Size = new Size(220, 54);
            btnJsonOku.TabIndex = 5;
            btnJsonOku.Text = ".JSON Dosyasını oku";
            btnJsonOku.TextAlign = ContentAlignment.MiddleRight;
            btnJsonOku.UseVisualStyleBackColor = false;
            btnJsonOku.Click += btnJsonOku_Click;
            // 
            // label14
            // 
            label14.BackColor = Color.White;
            label14.Location = new Point(443, 104);
            label14.Name = "label14";
            label14.Size = new Size(1, 520);
            label14.TabIndex = 4;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Yu Gothic", 12F);
            label16.ForeColor = SystemColors.ButtonHighlight;
            label16.Location = new Point(489, 434);
            label16.Name = "label16";
            label16.Size = new Size(298, 21);
            label16.TabIndex = 3;
            label16.Text = "150 Saatten az çalışan personel raporu";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Yu Gothic", 12F);
            label13.ForeColor = SystemColors.ButtonHighlight;
            label13.Location = new Point(484, 239);
            label13.Name = "label13";
            label13.Size = new Size(341, 21);
            label13.TabIndex = 3;
            label13.Text = "EXCEL formatına dönüştürmek için tıklayınız.";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Yu Gothic", 12F);
            label15.ForeColor = SystemColors.ButtonHighlight;
            label15.Location = new Point(84, 434);
            label15.Name = "label15";
            label15.Size = new Size(294, 21);
            label15.TabIndex = 2;
            label15.Text = ".JSON Dosyasını okumak için tıklayınız.";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Yu Gothic", 12F);
            label12.ForeColor = SystemColors.ButtonHighlight;
            label12.Location = new Point(69, 239);
            label12.Name = "label12";
            label12.Size = new Size(334, 21);
            label12.TabIndex = 2;
            label12.Text = ".JSON formatına dönüştürmek için tıklayınız.";
            // 
            // btnPDF
            // 
            btnPDF.BackColor = Color.Transparent;
            btnPDF.FlatStyle = FlatStyle.Flat;
            btnPDF.Font = new Font("Yu Gothic", 11.25F);
            btnPDF.ForeColor = SystemColors.ButtonHighlight;
            btnPDF.Image = Properties.Resources.image_gallery;
            btnPDF.ImageAlign = ContentAlignment.MiddleLeft;
            btnPDF.Location = new Point(561, 279);
            btnPDF.Name = "btnPDF";
            btnPDF.Size = new Size(172, 71);
            btnPDF.TabIndex = 1;
            btnPDF.Text = "EXCEL Formatına Dönüştür";
            btnPDF.TextAlign = ContentAlignment.MiddleRight;
            btnPDF.UseVisualStyleBackColor = false;
            btnPDF.Click += btnPDF_Click;
            // 
            // btnJSON
            // 
            btnJSON.BackColor = Color.Transparent;
            btnJSON.FlatStyle = FlatStyle.Flat;
            btnJSON.Font = new Font("Yu Gothic", 11.25F);
            btnJSON.ForeColor = SystemColors.ButtonHighlight;
            btnJSON.Image = Properties.Resources.image_gallery;
            btnJSON.ImageAlign = ContentAlignment.MiddleLeft;
            btnJSON.Location = new Point(172, 282);
            btnJSON.Name = "btnJSON";
            btnJSON.Size = new Size(167, 71);
            btnJSON.TabIndex = 0;
            btnJSON.Text = ".JSON Formatına Dönüştür";
            btnJSON.TextAlign = ContentAlignment.MiddleRight;
            btnJSON.UseVisualStyleBackColor = false;
            btnJSON.Click += btnJSON_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(34, 33, 74);
            ClientSize = new Size(1168, 725);
            Controls.Add(panelRaporlar);
            Controls.Add(panelDokumantasyon);
            Controls.Add(panelPersonelYonetimi);
            Controls.Add(panelGiris);
            Controls.Add(panel6);
            Controls.Add(pnlSideBar);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            pnlSideBar.ResumeLayout(false);
            pnlSideBar.PerformLayout();
            panel5.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel8.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panelGiris.ResumeLayout(false);
            panelGiris.PerformLayout();
            panelPersonelYonetimi.ResumeLayout(false);
            panelPersonelYonetimi.PerformLayout();
            panelDokumantasyon.ResumeLayout(false);
            panelDokumantasyon.PerformLayout();
            panelRaporlar.ResumeLayout(false);
            panelRaporlar.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlSideBar;
        private PictureBox pictureBox1;
        private Panel panel1;
        private Label lblLogo;
        private Panel panel2;
        private Button btnAnaSayfa;
        private Panel panel5;
        private Button btnRaporlar;
        private Panel panel3;
        private Button btnPersonelYonetimi;
        private Panel panel4;
        private Button btnDokumantasyon;
        private Panel panel6;
        private Label lblTimer;
        private System.Windows.Forms.Timer timer1;
        private Panel panel8;
        private Button btnCikisYap;
        private Label lblSayfaBilgisi;
        private Panel panel7;
        private Button btnSayfayiAsagiAl;
        private Panel panelGiris;
        private Label lblAnasayfa2;
        private Label lblAnasayfa1;
        private Label lblAnasayfa;
        private Label lblCizgi;
        private Label lblAnasayfa3;
        private Label lblAnasayfa4;
        private Panel panelPersonelYonetimi;
        private ComboBox cmbStatu;
        private ListView lstvBilgiCRUD;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private DateTimePicker dtpDogumTarihi;
        private TextBox txtSoyad;
        private TextBox txtAd;
        private ComboBox cmbMemurDerecesi;
        private Button btnSil;
        private Button btnGuncelle;
        private Button btnEkle;
        private Label label6;
        private Label label5;
        private MaskedTextBox mtbTelNo;
        private TextBox txtCalismaSaati;
        private Label label7;
        private TextBox txtYoneticiSaatlikUcret;
        private Label label8;
        private TextBox txtYoneticiBonusu;
        private Label label9;
        private Panel panelDokumantasyon;
        private Label label11;
        private Label label10;
        private ListView lstvMemurlar;
        private ListView lstvYoneticiler;
        private Panel panelRaporlar;
        private Button btnPDF;
        private Button btnJSON;
        private Label label14;
        private Label label13;
        private Label label12;
        private Button btnJsonOku;
        private Button btnAzCalisan;
        private Label label16;
        private Label label15;
    }
}
